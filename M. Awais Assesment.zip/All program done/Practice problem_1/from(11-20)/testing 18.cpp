#include<iostream>
using namespace std;
#include<conio.h>
int main()
{
	cout<<"Welcome to Program NO # 18";
	//Taking values from user
	

	int arr1[10],arr2[10],arr3[20];
	cout<<"\nEnter 5 values for First Array:";
		for(int i=0; i<5; i++)
	{
		cin>>arr1[i];
	}
		cout<<"\nEnter 5 values for second Array:";
		for(int i=0; i<5; i++)
	{
		cin>>arr2[i];
	}
	cout<<"Arrays after merging are:";
	for(int i=0;i<5;i++)
	{
		arr3[i]=arr1[i];
		arr3[i+5]=arr2[i];
		
	}
	for(int i=0;i<10; i++)
	{
		cout<<arr3[i]<<" ";
		
	}
}


#include<iostream>
using namespace std;
#include<conio.h>
int main()
{
	cout<<"Welcome to Program NO # 18";
	//Taking values from user
	int arr1[5],arr2[5],arr3[10];
	cout<<"\nEnter values for First Array:";
		for(int i=0; i<5; i++)
	{
		cout<<"\nEnter Value"<<i+1<<"=";
		cin>>arr1[i];
	}
		
		cout<<"\nEnter values for Second Array:";
			for(int i=0; i<5; i++)
	{
		cout<<"\nEnter Value"<<i+1<<"=";
		cin>>arr2[i];
	}
	int temp,k=0;
	for(int i=0;i<10;i++)
	{
		if(i>4)
		{
			arr3[i]=arr2[k];
			k++;
		}
		arr3[i]=arr1[i];
	}
	cout<<"Element of Array3 are:";
	for(int i=0;i<10;i++)
	{
		cout<<arr3[i];
	}
	
	for(int i=0;i<10-1;i++)
	{
		for(int j=i+1;j<10;j++)
		{
			if(arr3[i]<arr2[i])
			{
				temp = arr2[i];
				arr2[i] = arr2[j];
				arr2[j] = temp;
			}
		}
		}	
		cout<<"Sorted Elements of Array3 are:";
			for(int i=0;i<10;i++)
			{
				cout<<arr3[i];
			}

	
	


}
